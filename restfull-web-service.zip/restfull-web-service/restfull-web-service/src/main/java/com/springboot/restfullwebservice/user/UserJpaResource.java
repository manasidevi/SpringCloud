package com.springboot.restfullwebservice.user;

import java.net.URI;
import java.util.List;
//import org.springframework.hateoas.Link;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ServerProperties.Tomcat.Resource;
//import org.springframework.hateoas.server.mvc.ControllerLinkBuilder;
//import static  org.springframework.hateoas.server.mvc.ControllerLinkBuilder.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.springboot.restfullwebservice.exceptions.UserNotFoundException;

@RestController
public class UserJpaResource {
	@Autowired
	private UserDaoService userDao;
	@Autowired
	private UserRepository userRepository ;
	@Autowired
	private PostRepository postRepository ;
	@GetMapping("jpa/users")
	public List<User> retriveAllUsers()
	
	{
	return  userRepository.findAll();	
	}

	@GetMapping("jpa/user/{id}")
	public Optional<User> retriveUsers(@PathVariable Integer id)
	
	{
		Optional<User> user=userRepository.findById(id);
		if(!user.isPresent()) {
			throw new UserNotFoundException("id-"+user.get());
		}
		
	
	return  user;	
	}
	@PostMapping("jpa/users/{id}/post")
	public ResponseEntity<Object> createPost(@Valid @PathVariable int id, @RequestBody Post post)
		{
		
		Optional<User> userOptional=userRepository.findById(id);
		if(!userOptional.isPresent()) {
			throw new UserNotFoundException("id-"+userOptional.get());
		}	
		User user= userOptional.get(); 
		post.setUser(user);
		postRepository.save(post);
	 
	    URI location =ServletUriComponentsBuilder.
	   fromCurrentRequestUri()
	   .path("/{id}")
	    .buildAndExpand(post.getId()).toUri();
	
	   return ResponseEntity.created(location).build();
	
		}
	@DeleteMapping("jpa/user/{id}")
	public void deleteUser(@PathVariable Integer id) {
		userRepository.deleteById(id);
		/*
		 * if(user==null) { throw new UserNotFoundException("id-"+user.getId()); }
		 */
		
		
	}
	@GetMapping("jpa/user/{id}/posts")
	public Optional<User> retriveAllUser(@PathVariable Integer id)
	
	{
		Optional<User> user=userRepository.findById(id);
		if(!user.isPresent()) {
			throw new UserNotFoundException("id-"+user.get());
		}
		user.get().getPost();
	
	return  user;	
	}
	
}

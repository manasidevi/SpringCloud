insert into user values(101,sysdate(),'Abhi');
insert into user values(103,sysdate(),'Ashya');
insert into user values(102,sysdate(),'Ammu');
insert into post values(1001,'my first post',101);
insert into post values(1002,'my second post',102);
insert into post values(1003,'my 3rd post',101);
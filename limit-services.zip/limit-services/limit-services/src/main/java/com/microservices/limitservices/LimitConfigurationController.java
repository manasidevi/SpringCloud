package com.microservices.limitservices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.limitservices.bean.LimitConfiguration;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class LimitConfigurationController {
	@Autowired
	Configuration config;
	@GetMapping("/limit")
	public LimitConfiguration retriveLimitFromConfiguration() {
		return new LimitConfiguration(config.getMaximum(), config.getMinimum());
		
	}
	@GetMapping("/falut=tolerance-example")
	@HystrixCommand(fallbackMethod="fallBackRetriveConfiguration")
	public LimitConfiguration retriveConfiguration(){
		  throw new RuntimeException("Not availble");	
		
	}
	public LimitConfiguration fallBackRetriveConfiguration() {
		return new LimitConfiguration(9,999);
	}
	
}
